# Library Management System - Flask Website

## Run on Windows

1. Install Python 3.10+.
2. Open Command Prompt in this folder.
3. Run:
   `python -m pip install -r requirements.txt`
4. Start:
   `python app.py`
5. Open `http://127.0.0.1:5000` in Chrome.

The app creates `library.db` automatically.

## Features
- Dashboard and statistics
- Add, view, search, edit and delete books
- Borrow and return books
- Available/Borrowed status
- Borrower and borrow-time tracking
- Member management
- SQLite database persistence
- Responsive design
