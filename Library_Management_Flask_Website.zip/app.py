from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from datetime import datetime

app = Flask(__name__)
app.secret_key = "library-management-secret-key"
DB = "library.db"


def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS books (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL UNIQUE,
            author TEXT NOT NULL DEFAULT '',
            isbn TEXT NOT NULL DEFAULT '',
            category TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL DEFAULT 'Available',
            borrower TEXT DEFAULT '',
            borrowed_at TEXT DEFAULT '',
            created_at TEXT NOT NULL
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS members (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL DEFAULT '',
            phone TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()


@app.route("/")
def dashboard():
    conn = get_db()
    total = conn.execute("SELECT COUNT(*) FROM books").fetchone()[0]
    available = conn.execute("SELECT COUNT(*) FROM books WHERE status='Available'").fetchone()[0]
    borrowed = conn.execute("SELECT COUNT(*) FROM books WHERE status='Borrowed'").fetchone()[0]
    members = conn.execute("SELECT COUNT(*) FROM members").fetchone()[0]
    recent = conn.execute("SELECT * FROM books ORDER BY id DESC LIMIT 5").fetchall()
    conn.close()
    return render_template("dashboard.html", total=total, available=available,
                           borrowed=borrowed, members=members, recent=recent)


@app.route("/books")
def books():
    q = request.args.get("q", "").strip()
    conn = get_db()
    if q:
        rows = conn.execute(
            "SELECT * FROM books WHERE title LIKE ? OR author LIKE ? OR isbn LIKE ? OR category LIKE ? ORDER BY id DESC",
            (f"%{q}%", f"%{q}%", f"%{q}%", f"%{q}%")
        ).fetchall()
    else:
        rows = conn.execute("SELECT * FROM books ORDER BY id DESC").fetchall()
    conn.close()
    return render_template("books.html", books=rows, q=q)


@app.route("/books/add", methods=["GET", "POST"])
def add_book():
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        author = request.form.get("author", "").strip()
        isbn = request.form.get("isbn", "").strip()
        category = request.form.get("category", "").strip()

        if not title:
            flash("Book title is required.", "error")
            return redirect(url_for("add_book"))

        conn = get_db()
        try:
            conn.execute(
                "INSERT INTO books(title, author, isbn, category, created_at) VALUES (?, ?, ?, ?, ?)",
                (title, author, isbn, category, datetime.now().strftime("%Y-%m-%d %H:%M"))
            )
            conn.commit()
            flash("Book added successfully.", "success")
        except sqlite3.IntegrityError:
            flash("Book already exists.", "error")
        finally:
            conn.close()
        return redirect(url_for("books"))

    return render_template("book_form.html", book=None)


@app.route("/books/<int:book_id>/edit", methods=["GET", "POST"])
def edit_book(book_id):
    conn = get_db()
    book = conn.execute("SELECT * FROM books WHERE id=?", (book_id,)).fetchone()

    if not book:
        conn.close()
        flash("Book not found.", "error")
        return redirect(url_for("books"))

    if request.method == "POST":
        title = request.form.get("title", "").strip()
        author = request.form.get("author", "").strip()
        isbn = request.form.get("isbn", "").strip()
        category = request.form.get("category", "").strip()

        if not title:
            conn.close()
            flash("Book title is required.", "error")
            return redirect(url_for("edit_book", book_id=book_id))

        try:
            conn.execute(
                "UPDATE books SET title=?, author=?, isbn=?, category=? WHERE id=?",
                (title, author, isbn, category, book_id)
            )
            conn.commit()
            flash("Book updated successfully.", "success")
        except sqlite3.IntegrityError:
            flash("Another book already has this title.", "error")
        conn.close()
        return redirect(url_for("books"))

    conn.close()
    return render_template("book_form.html", book=book)


@app.post("/books/<int:book_id>/delete")
def delete_book(book_id):
    conn = get_db()
    conn.execute("DELETE FROM books WHERE id=?", (book_id,))
    conn.commit()
    conn.close()
    flash("Book deleted successfully.", "success")
    return redirect(url_for("books"))


@app.post("/books/<int:book_id>/borrow")
def borrow_book(book_id):
    borrower = request.form.get("borrower", "").strip()
    if not borrower:
        flash("Enter the member name before borrowing.", "error")
        return redirect(url_for("books"))

    conn = get_db()
    book = conn.execute("SELECT * FROM books WHERE id=?", (book_id,)).fetchone()
    if not book:
        flash("Book not found.", "error")
    elif book["status"] == "Borrowed":
        flash("Book is already borrowed.", "error")
    else:
        conn.execute(
            "UPDATE books SET status='Borrowed', borrower=?, borrowed_at=? WHERE id=?",
            (borrower, datetime.now().strftime("%Y-%m-%d %H:%M"), book_id)
        )
        conn.commit()
        flash("Book borrowed successfully.", "success")
    conn.close()
    return redirect(url_for("books"))


@app.post("/books/<int:book_id>/return")
def return_book(book_id):
    conn = get_db()
    book = conn.execute("SELECT * FROM books WHERE id=?", (book_id,)).fetchone()
    if not book:
        flash("Book not found.", "error")
    elif book["status"] == "Available":
        flash("Book was not borrowed.", "error")
    else:
        conn.execute(
            "UPDATE books SET status='Available', borrower='', borrowed_at='' WHERE id=?",
            (book_id,)
        )
        conn.commit()
        flash("Book returned successfully.", "success")
    conn.close()
    return redirect(url_for("books"))


@app.route("/members")
def members():
    conn = get_db()
    rows = conn.execute("SELECT * FROM members ORDER BY id DESC").fetchall()
    conn.close()
    return render_template("members.html", members=rows)


@app.post("/members/add")
def add_member():
    name = request.form.get("name", "").strip()
    email = request.form.get("email", "").strip()
    phone = request.form.get("phone", "").strip()

    if not name:
        flash("Member name is required.", "error")
    else:
        conn = get_db()
        conn.execute(
            "INSERT INTO members(name,email,phone,created_at) VALUES (?,?,?,?)",
            (name, email, phone, datetime.now().strftime("%Y-%m-%d %H:%M"))
        )
        conn.commit()
        conn.close()
        flash("Member added successfully.", "success")
    return redirect(url_for("members"))


@app.post("/members/<int:member_id>/delete")
def delete_member(member_id):
    conn = get_db()
    conn.execute("DELETE FROM members WHERE id=?", (member_id,))
    conn.commit()
    conn.close()
    flash("Member deleted successfully.", "success")
    return redirect(url_for("members"))


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
